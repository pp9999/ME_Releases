energy things
